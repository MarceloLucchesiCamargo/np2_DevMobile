import 'package:flutter/material.dart';

import '../estado/app_state.dart';
import '../modelos/produto.dart';

// esta tela mostra todas as informações de um produto
// funciona como uma "página de detalhes" quando a pessoa clica em um item da loja
class DetalhesProdutoPage extends StatelessWidget {
  // guarda o produto que será mostrado na tela
  // é como dizer: "este é o produto que queremos ver em detalhe"
  final Produto produto;

  // permite acessar o estado geral do app
  // isso é usado para adicionar coisas ao carrinho
  final AppState appState;

  const DetalhesProdutoPage({
    super.key,
    required this.produto,
    required this.appState,
  });

  // esta função é chamada quando a pessoa aperta o botão de adicionar ao carrinho
  // ela pega o produto atual e coloca dentro da lista de compras
  void _adicionarAoCarrinho(BuildContext context) {
    appState.adicionarAoCarrinho(produto); // coloca o produto no carrinho

    // mostra uma mensagem rápida na tela avisando que funcionou
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('"${produto.titulo}" adicionado ao carrinho.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // barra no topo da tela com o nome da página
      appBar: AppBar(
        title: const Text('Detalhes do produto'), // título simples para a usuária se localizar
      ),

      // permite que a tela role caso tenha muito conteúdo
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0), // cria espaço ao redor do conteúdo
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch, // faz tudo ocupar toda a largura da tela
          children: [
            // área onde mostramos a imagem do produto
            SizedBox(
              height: 200, // define o tamanho da imagem
              child: Image.network(
                produto.imagemUrl, // pega a imagem que veio do produto
                fit: BoxFit.contain, // ajusta a imagem sem cortar
                errorBuilder: (context, error, stackTrace) {
                  // se a imagem der erro, mostra um ícone no lugar
                  return const Icon(Icons.image_not_supported, size: 64);
                },
              ),
            ),

            const SizedBox(height: 16), // espaço entre a imagem e o texto

            // mostra o nome do produto
            // é o título principal e deve chamar mais atenção
            Text(
              produto.titulo,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 8),

            // mostra a categoria do produto
            // isso ajuda a entender "onde ele se encaixa" dentro da loja
            Text(
              'Categoria: ${produto.categoria}',
              style: const TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
            ),

            const SizedBox(height: 8),

            // mostra o preço já formatado bonitinho
            // o número é convertido para sempre ter duas casas decimais
            Text(
              'R\$ ${produto.preco.toStringAsFixed(2)}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
            ),

            const SizedBox(height: 16),

            // título da parte onde vem a descrição
            // como se fosse um subtítulo
            const Text(
              'Descrição',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),

            const SizedBox(height: 4),

            // o texto que explica o produto com mais detalhes
            // aqui pode ter informações técnicas, benefícios, etc.
            Text(
              produto.descricao,
              style: const TextStyle(fontSize: 14),
            ),

            const SizedBox(height: 24), // espaço antes do botão

            // botão que adiciona o produto ao carrinho
            // ocupa toda a largura para ficar mais fácil de clicar
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _adicionarAoCarrinho(context), // quando clicar, chama a função
                child: const Text('Adicionar ao carrinho'), // texto do botão
              ),
            ),
          ],
        ),
      ),
    );
  }
}