import 'package:flutter/material.dart';

import '../estado/app_state.dart';
import '../rotas.dart';

// esta classe cria a tela de login
// ela mostra os campos de e-mail e senha
// também cuida de mandar a usuária para outras telas
class LoginPage extends StatefulWidget {
  // isso guarda o estado geral do app
  // serve para salvar informações importantes, como o e-mail da usuária
  final AppState appState;

  const LoginPage({super.key, required this.appState});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

// esta classe controla o que muda na tela
// ela guarda os textos digitados e cria as ações dos botões
class _LoginPageState extends State<LoginPage> {
  // isso guarda o texto que a usuária digita no campo de e-mail
  final TextEditingController controladorEmail = TextEditingController();

  // isso guarda o texto da senha digitada
  // a senha não é checada de verdade, é só visual mesmo
  final TextEditingController controladorSenha = TextEditingController();

  @override
  void dispose() {
    // isso limpa os controladores quando a tela fecha
    controladorEmail.dispose();
    controladorSenha.dispose();
    super.dispose();
  }

  // esta função faz o login
  // ela pega o e-mail digitado, salva no estado geral
  // e depois envia para a tela da loja
  void _realizarLogin() {
    final String email = controladorEmail.text.trim();

    // isso salva o e-mail no app
    widget.appState.fazerLogin(email);

    // isso troca a tela e vai direto pra loja
    Navigator.pushReplacementNamed(context, RotasApp.lojaPage);
  }

  // esta função abre a tela de registro
  // usada quando a usuária quer criar uma conta nova
  void _abrirRegistro() {
    Navigator.pushNamed(context, RotasApp.registroPage);
  }

  @override
  Widget build(BuildContext context) {
    // isso monta toda a interface visual da tela
    return Scaffold(
      appBar: AppBar(
        // isso mostra o título na parte de cima da tela
        title: const Text(
          'Login - Loja Fake MegaStore',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.normal,
          ),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          // isso centraliza os itens no meio da tela
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // isso mostra o título grande da tela
            const Text(
              'Bem-vindo à Loja Fake MegaStore',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 40),

            // isso é o campo onde a usuária digita o e-mail
            TextField(
              controller: controladorEmail,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'E-mail',
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 24),

            // isso é o campo onde a usuária digita a senha
            // o texto fica escondido por segurança visual
            TextField(
              controller: controladorSenha,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Senha',
                prefixIcon: Icon(Icons.lock),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 40),

            // isso cria o botão de login
            // quando clicado, chama a função de login
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _realizarLogin,
                child: const Text('Entrar'),
              ),
            ),

            const SizedBox(height: 20),

            // isso cria o botão para ir à tela de criar conta
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _abrirRegistro,
                child: const Text('Criar conta'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
