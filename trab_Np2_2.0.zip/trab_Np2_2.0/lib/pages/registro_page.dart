import 'package:flutter/material.dart';

import '../estado/app_state.dart';

// essa tela serve para simular o cadastro de uma nova usuária
// nela coletamos nome, e-mail, senha e confirmação de senha
// não salva nada de verdade, apenas mostra o fluxo de formulário
class RegistroPage extends StatefulWidget {
  // appState é recebido para manter o padrão do projeto
  // neste arquivo não usamos appState para gravar, apenas mantemos a assinatura
  final AppState appState;

  const RegistroPage({super.key, required this.appState});

  @override
  State<RegistroPage> createState() => _RegistroPageState();
}

class _RegistroPageState extends State<RegistroPage> {
  // controladores: cada um guarda o texto digitado em um campo
  // você usa esses controladores para ler o que a pessoa escreveu
  // e também para limpar ou preencher os campos se precisar
  final TextEditingController controladorNome = TextEditingController();
  final TextEditingController controladorEmail = TextEditingController();
  final TextEditingController controladorSenha = TextEditingController();
  final TextEditingController controladorConfirmacaoSenha =
      TextEditingController();

  @override
  void dispose() {
    // dispose libera os controladores da memória quando a tela fecha
    // isso evita vazamento de memória em aplicativos maiores
    controladorNome.dispose();
    controladorEmail.dispose();
    controladorSenha.dispose();
    controladorConfirmacaoSenha.dispose();
    super.dispose();
  }

  // função chamada ao clicar em "cadastrar"
  // ela lê os valores dos controladores, valida e mostra mensagens
  void _registrarUsuario() {
    // pega o texto digitado em cada campo
    final nome = controladorNome.text.trim(); // trim remove espaços nas pontas
    final email = controladorEmail.text.trim();
    final senha = controladorSenha.text;
    final confirmacao = controladorConfirmacaoSenha.text;

    // validação 1: nenhum campo pode estar vazio
    // se algum estiver vazio, mostramos um aviso e paramos a função
    if (nome.isEmpty || email.isEmpty || senha.isEmpty || confirmacao.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          // snackbars são mensagens rápidas que aparecem na parte de baixo
          content: Text('preencha todos os campos para se cadastrar.'),
        ),
      );
      return; // sai da função sem continuar
    }

    // validação 2: senha e confirmação precisam ser iguais
    // se não forem, mostramos aviso e paramos
    if (senha != confirmacao) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('as senhas não conferem.'),
        ),
      );
      return;
    }

    // se chegou até aqui, significa que a validação passou
    // aqui apenas simulamos o cadastro mostrando uma mensagem
    // em um app real, você mandaria os dados para um servidor ou salvaria localmente
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('cadastro realizado para $nome (simulado).'),
      ),
    );

    // depois de "cadastrar" voltamos para a tela anterior (login)
    // navigator.pop remove a tela atual da pilha e retorna para quem veio antes
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    // scaffold é a estrutura básica de uma tela no flutter
    // appbar aparece em cima, body é o conteúdo principal
    return Scaffold(
      appBar: AppBar(
        // título simples para a usuária identificar a tela
        title: const Text(
          'registro - loja fake megastore',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.normal,
          ),
        ),
      ),

      // body com padding para não encostar nas bordas da tela
      body: Padding(
        padding: const EdgeInsets.all(24.0),

        // usamos uma coluna para empilhar os elementos verticalmente
        child: Column(
          // centraliza verticalmente para ficar agradável na tela
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // título principal da tela
            const Text(
              'criar nova conta',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 40), // espaço visual entre elementos

            // campo de texto para nome completo
            // controller: conecta o campo ao controlador definido no topo
            // decoration: define rótulo, ícone e borda visual do campo
            TextField(
              controller: controladorNome,
              decoration: const InputDecoration(
                labelText: 'nome completo',
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 24),

            // campo de texto para e-mail
            // keyboardType especifica que é um e-mail (ajuda no teclado do celular)
            TextField(
              controller: controladorEmail,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'e-mail',
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 24),

            // campo para senha
            // obscureText esconde o texto digitado (aparece bolinhas)
            TextField(
              controller: controladorSenha,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'senha',
                prefixIcon: Icon(Icons.lock),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 24),

            // campo para confirmar a senha
            // o objetivo é reduzir erro de digitação na senha
            TextField(
              controller: controladorConfirmacaoSenha,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'confirmar senha',
                prefixIcon: Icon(Icons.lock_outline),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 40),

            // botão principal que tenta cadastrar a usuária
            // ocupando toda a largura para ficar fácil de clicar
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _registrarUsuario, // chama a função que valida e registra
                child: const Text('cadastrar'),
              ),
            ),

            const SizedBox(height: 20),

            // botão secundário que volta para a tela de login sem cadastrar
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  // volta uma tela na pilha, retornando ao login
                  Navigator.pop(context);
                },
                child: const Text('voltar para login'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
