import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../estado/app_state.dart';
import '../rotas.dart';

// essa tela permite que a usuária veja e edite os dados do próprio perfil
// aqui ficam nome, e-mail e endereço de entrega
// também é possível fazer logout a partir daqui
class PerfilPage extends StatefulWidget {
  // o appstate guarda todas as informações globais da usuária
  // e permite acesso aos dados atuais e funções como logout
  final AppState appState;

  const PerfilPage({super.key, required this.appState});

  @override
  State<PerfilPage> createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {
  // controladores: guardam o texto escrito nos campos da tela
  // com eles conseguimos preencher automaticamente e ler depois
  final TextEditingController controladorNome = TextEditingController();
  final TextEditingController controladorEmail = TextEditingController();
  final TextEditingController controladorCidade = TextEditingController();
  final TextEditingController controladorEstado = TextEditingController();
  final TextEditingController controladorCep = TextEditingController();
  final TextEditingController controladorBairro = TextEditingController();
  final TextEditingController controladorRua = TextEditingController();
  final TextEditingController controladorNumero = TextEditingController();

  // essa variável controla se a tela está no modo de edição
  // modo edição = campos habilitados / modo visualização = campos bloqueados
  bool modoEdicao = false;

  @override
  void initState() {
    super.initState();
    // quando a tela abre, carregamos os dados salvos no appstate
    // e colocamos eles dentro dos controladores
    _carregarDadosDoEstado();
  }

  @override
  void dispose() {
    // libera memória dos controladores quando a tela é fechada
    controladorNome.dispose();
    controladorEmail.dispose();
    controladorCidade.dispose();
    controladorEstado.dispose();
    controladorCep.dispose();
    controladorBairro.dispose();
    controladorRua.dispose();
    controladorNumero.dispose();
    super.dispose();
  }

  // essa função lê os dados armazenados no appstate
  // e coloca esses valores dentro dos campos do formulário
  void _carregarDadosDoEstado() {
    final appState = widget.appState;

    controladorNome.text = appState.nomeUsuario ?? '';
    controladorEmail.text = appState.emailUsuario ?? '';
    controladorCidade.text = appState.cidadeEntrega ?? '';
    controladorEstado.text = appState.estadoEntrega ?? '';
    controladorCep.text = appState.cepEntrega ?? '';
    controladorBairro.text = appState.bairroEntrega ?? '';
    controladorRua.text = appState.ruaEntrega ?? '';
    controladorNumero.text = appState.numeroEntrega ?? '';
  }

  // função chamada ao clicar em "sair da conta"
  // limpa os dados do usuário, carrinho, perfil, etc.
  // e redireciona para a tela de login
  void _fazerLogout(BuildContext context) {
    widget.appState.fazerLogout();

    Navigator.pushNamedAndRemoveUntil(
      context,
      RotasApp.loginPage,
      (route) => false, // remove todas as telas anteriores da pilha
    );
  }

  // ativa o modo edição, permitindo alterar os campos
  void _entrarEmModoEdicao() {
    setState(() {
      modoEdicao = true;
    });
  }

  // cancela as alterações e restaura os dados originais
  void _cancelarEdicao() {
    setState(() {
      _carregarDadosDoEstado(); // restaura tudo como estava
      modoEdicao = false;       // volta para modo visualização
    });
  }

  // salva os novos dados dentro do appstate
  // e volta para o modo visualização
  void _salvarPerfil() {
    final nome = controladorNome.text.trim();
    final email = controladorEmail.text.trim();
    final cidade = controladorCidade.text.trim();
    final estado = controladorEstado.text.trim();
    final cep = controladorCep.text.trim();
    final bairro = controladorBairro.text.trim();
    final rua = controladorRua.text.trim();
    final numero = controladorNumero.text.trim();

    // envia os dados atualizados para o appstate
    widget.appState.atualizarPerfil(
      nome: nome,
      email: email,
      cidade: cidade,
      estado: estado,
      cep: cep,
      bairro: bairro,
      rua: rua,
      numero: numero,
    );

    setState(() {
      modoEdicao = false; // volta para os campos bloqueados
    });

    // mensagem rápida avisando que salvou com sucesso
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('perfil atualizado com sucesso.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    // scaffold é a estrutura principal da tela
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'perfil - loja fake megastore',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
        ),
      ),

      // singlechildscrollview permite rolar a tela se precisar
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),

        child: Column(
          children: [
            // título da tela
            const Text(
              'perfil do usuário',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),

            const SizedBox(height: 32),

            // campo nome completo
            // enabled = depende se está editando ou só vendo
            TextField(
              controller: controladorNome,
              enabled: modoEdicao,
              decoration: const InputDecoration(
                labelText: 'nome completo',
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            // campo e-mail
            TextField(
              controller: controladorEmail,
              enabled: modoEdicao,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'e-mail',
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 24),

            // título da parte de endereço
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'endereço para entrega',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
            ),

            const SizedBox(height: 16),

            // cidade
            TextField(
              controller: controladorCidade,
              enabled: modoEdicao,
              decoration: const InputDecoration(
                labelText: 'cidade',
                prefixIcon: Icon(Icons.location_city),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            // estado
            TextField(
              controller: controladorEstado,
              enabled: modoEdicao,
              decoration: const InputDecoration(
                labelText: 'estado (uf)',
                prefixIcon: Icon(Icons.map),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            // cep
            TextField(
              controller: controladorCep,
              enabled: modoEdicao,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly, // só números
              ],
              decoration: const InputDecoration(
                labelText: 'cep',
                prefixIcon: Icon(Icons.local_post_office),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            // bairro
            TextField(
              controller: controladorBairro,
              enabled: modoEdicao,
              decoration: const InputDecoration(
                labelText: 'bairro',
                prefixIcon: Icon(Icons.location_on),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            // rua
            TextField(
              controller: controladorRua,
              enabled: modoEdicao,
              decoration: const InputDecoration(
                labelText: 'rua',
                prefixIcon: Icon(Icons.home),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            // número
            TextField(
              controller: controladorNumero,
              enabled: modoEdicao,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
              ],
              decoration: const InputDecoration(
                labelText: 'número',
                prefixIcon: Icon(Icons.confirmation_number),
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 32),

            // se não está editando, mostra botões normais
            if (!modoEdicao) ...[
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _entrarEmModoEdicao,
                  child: const Text('editar perfil'),
                ),
              ),

              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => _fazerLogout(context),
                  child: const Text('sair da conta'),
                ),
              ),
            ]

            // se está editando, mostra salvar e cancelar
            else ...[
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _salvarPerfil,
                  child: const Text('salvar alterações'),
                ),
              ),

              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _cancelarEdicao,
                  child: const Text('cancelar'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
