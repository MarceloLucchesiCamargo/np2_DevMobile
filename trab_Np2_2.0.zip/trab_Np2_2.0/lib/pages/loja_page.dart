import 'package:flutter/material.dart';

import '../estado/app_state.dart';
import '../servicos/api_service.dart';
import '../modelos/produto.dart';
import '../rotas.dart';

class LojaPage extends StatefulWidget {
  final AppState appState;

  const LojaPage({super.key, required this.appState});

  @override
  State<LojaPage> createState() => _LojaPageState();
}

class _LojaPageState extends State<LojaPage> {
  // isso cria o serviço que busca os produtos na api
  final ApiService apiService = ApiService();

  // isso guarda a lista futura de produtos carregada uma vez
  late Future<List<Produto>> futuroProdutos;

  @override
  void initState() {
    super.initState();
    // isso carrega os produtos quando a tela abre
    futuroProdutos = apiService.buscarProdutos();
  }

  // isso abre a tela do carrinho
  // ao voltar, atualiza a tela para mostrar a nova quantidade no carrinho
  void _abrirCarrinho() {
    Navigator.pushNamed(context, RotasApp.carrinhoPage).then((_) {
      setState(() {});
    });
  }

  // isso abre a tela de perfil do usuário
  void _abrirPerfil() {
    Navigator.pushNamed(context, RotasApp.perfilPage);
  }

  // isso abre os detalhes de um produto quando clicado
  // ao voltar, atualiza a quantidade do carrinho
  void _abrirDetalhesProduto(Produto produto) {
    Navigator.pushNamed(
      context,
      RotasApp.detalhesProdutoPage,
      arguments: produto,
    ).then((_) {
      setState(() {});
    });
  }

  // isso cria o ícone do carrinho com uma bolinha vermelha mostrando quantos itens tem
  Widget _buildIconeCarrinho() {
    final int quantidade = widget.appState.quantidadeTotalCarrinho;

    return Stack(
      alignment: Alignment.center,
      children: [
        // isso é o botão do carrinho
        IconButton(
          onPressed: _abrirCarrinho,
          icon: const Icon(Icons.shopping_cart),
        ),

        // isso mostra a bolinha vermelha só quando tem itens no carrinho
        if (quantidade > 0)
          Positioned(
            right: 6,
            top: 6,
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(
                color: Colors.red,
                shape: BoxShape.circle,
              ),
              constraints: const BoxConstraints(
                minWidth: 18,
                minHeight: 18,
              ),
              child: Center(
                // isso mostra a quantidade dentro da bolinha
                child: Text(
                  quantidade.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // isso cria a barra superior da tela
      appBar: AppBar(
        title: const Text('Loja Fake MegaStore'),
        actions: [
          // isso coloca o ícone do carrinho na barra
          _buildIconeCarrinho(),

          // isso coloca o botão do perfil
          IconButton(
            onPressed: _abrirPerfil,
            icon: const Icon(Icons.person),
          ),
        ],
      ),

      body: Column(
        children: [
          // isso é um texto simples de boas-vindas
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Bem-vindo(a),',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  'Confira os produtos da Fake MegaStore',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  'Toque em um produto para ver mais detalhes.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // isso ocupa todo o espaço restante com a lista de produtos
          Expanded(
            child: FutureBuilder<List<Produto>>(
              future: futuroProdutos,

              // isso controla o que aparece dependendo do estado da busca
              builder: (context, snapshot) {
                // isso mostra o círculo de carregamento enquanto busca os produtos
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                // isso mostra um erro caso a busca dê errado
                if (snapshot.hasError) {
                  return Center(
                    child: Text(
                      'Erro ao carregar produtos:\n${snapshot.error}',
                      textAlign: TextAlign.center,
                    ),
                  );
                }

                // isso pega a lista de produtos carregada
                final List<Produto> produtos = snapshot.data ?? [];

                // isso mostra uma mensagem se a lista vier vazia
                if (produtos.isEmpty) {
                  return const Center(
                    child: Text('Nenhum produto encontrado na loja.'),
                  );
                }

                // isso cria o grid com os produtos
                return GridView.builder(
                  padding: const EdgeInsets.all(8.0),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // isso define duas colunas
                    childAspectRatio: 0.70, // isso controla o formato do card
                    crossAxisSpacing: 8, // isso coloca espaço horizontal
                    mainAxisSpacing: 8, // isso coloca espaço vertical
                  ),
                  itemCount: produtos.length,

                  // isso cria cada card do grid
                  itemBuilder: (context, index) {
                    final Produto produto = produtos[index];

                    return GestureDetector(
                      // isso ativa quando o produto é clicado
                      onTap: () => _abrirDetalhesProduto(produto),

                      child: Card(
                        elevation: 3,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),

                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // isso mostra a imagem do produto
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Image.network(
                                  produto.imagemUrl,
                                  fit: BoxFit.contain,

                                  // isso aparece caso a imagem dê erro
                                  errorBuilder: (context, error, stackTrace) {
                                    return const Icon(
                                      Icons.image_not_supported,
                                      size: 48,
                                    );
                                  },
                                ),
                              ),
                            ),

                            // isso mostra o nome do produto
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8.0,
                              ),
                              child: Text(
                                produto.titulo,
                                maxLines: 2, // isso limita o nome em 2 linhas
                                overflow: TextOverflow.ellipsis, // isso põe "..." no final
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),

                            const SizedBox(height: 4),

                            // isso mostra o preço do produto
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8.0,
                              ),
                              child: Text(
                                // isso converte o preço pra sempre mostrar 2 casas decimais
                                'R\$ ${produto.preco.toStringAsFixed(2)}',
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue,
                                ),
                              ),
                            ),

                            const SizedBox(height: 8),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
