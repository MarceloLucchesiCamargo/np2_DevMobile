import 'package:flutter/material.dart';

import '../estado/app_state.dart';
import '../modelos/produto.dart';

// esta tela mostra tudo que a pessoa colocou no carrinho
// aqui ela pode ver os itens, aumentar quantidade, diminuir e finalizar
class CarrinhoPage extends StatefulWidget {
  final AppState appState; // acesso ao estado geral do app, onde o carrinho fica guardado

  const CarrinhoPage({super.key, required this.appState});

  @override
  State<CarrinhoPage> createState() => _CarrinhoPageState();
}

class _CarrinhoPageState extends State<CarrinhoPage> {
  @override
  Widget build(BuildContext context) {
    final itens = widget.appState.itensCarrinho; // lista com todos os produtos adicionados
    final double total = widget.appState.totalCarrinho; // soma total dos valores

    // se nao tiver nada no carrinho, mostra uma tela dizendo isso
    if (itens.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Carrinho'), // nome da página
        ),
        body: const Center(
          child: Text('Seu carrinho está vazio'), // mensagem simples
        ),
      );
    }

    // aqui agrupamos produtos repetidos
    // se o carrinho tiver 3 copias de um produto, aqui ele vira "produto: 3"
    final Map<Produto, int> mapaQuantidade = {}; // guarda cada produto e quantas vezes aparece
    for (final produto in itens) {
      mapaQuantidade[produto] = (mapaQuantidade[produto] ?? 0) + 1; // soma 1 para cada copia encontrada
    }

    // transforma o mapa em lista para exibir na tela
    final List<MapEntry<Produto, int>> listaAgrupada =
        mapaQuantidade.entries.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Carrinho'), // nome da tela
      ),
      body: Column(
        children: [
          // parte de cima: lista rolável dos produtos
          Expanded(
            child: ListView.builder(
              itemCount: listaAgrupada.length, // quantidade de produtos diferentes
              itemBuilder: (context, index) {
                final entrada = listaAgrupada[index]; // entrada: produto + quantidade
                final Produto produto = entrada.key; // item que está no carrinho
                final int quantidade = entrada.value; // quantas unidades dele existem

                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6), // espaço entre os cards
                  elevation: 3, // pequena sombra
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8), // cantos arredondados
                    side: BorderSide(
                      color: Colors.grey.shade300, // borda discreta
                    ),
                  ),
                  child: ListTile(
                    leading: Image.network(
                      produto.imagemUrl, // mostra a imagem do produto
                      width: 40,
                      height: 40,
                      fit: BoxFit.contain, // ajusta sem cortar
                      errorBuilder: (context, error, stackTrace) =>
                          const Icon(Icons.image_not_supported), // se falhar, mostra um ícone
                    ),
                    title: Text(produto.titulo), // nome do produto
                    subtitle: Text(
                      'R\$ ${produto.preco.toStringAsFixed(2)}  |  Qtd: $quantidade', // preço + quantidade
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min, // impede a row de ocupar muito espaço
                      children: [
                        // botão que tira 1 unidade do produto
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline), // ícone de menos
                          onPressed: () {
                            setState(() {
                              widget.appState
                                  .removerUmaUnidadeDoCarrinho(produto); // tira uma unidade
                            });
                          },
                        ),

                        const SizedBox(width: 4),

                        // botão que adiciona mais uma unidade
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline), // ícone de mais
                          onPressed: () {
                            setState(() {
                              widget.appState.adicionarAoCarrinho(produto); // adiciona mais uma
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // parte de baixo da tela: total + botoes de ação
          Container(
            width: double.infinity, // ocupa toda a largura
            color: Colors.grey.shade200, // fundo leve
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 12.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // linha com "Total:" e o valor total
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween, // separa texto e valor
                  children: [
                    const Text(
                      'Total:',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'R\$ ${total.toStringAsFixed(2)}', // total formatado
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue, // destaque
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // botão que "finaliza" a compra (simulação)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: const Text('Compra finalizada'), // titulo do aviso
                            content: const Text(
                              'Pedido realizado com sucesso!\n'
                              'Obrigado por comprar na Fake MegaStore. Seu pedido está sendo preparado.\n'
                              'Fim da simulação!', // texto explicando a simulação
                            ),
                            actions: [
                              // botão que fecha o aviso
                              TextButton(
                                onPressed: () {
                                  widget.appState.esvaziarCarrinho(); // limpa tudo
                                  Navigator.pop(context); // fecha o popup
                                  setState(() {}); // atualiza a tela
                                },
                                child: const Text('OK'),
                              ),
                            ],
                          );
                        },
                      );
                    },
                    child: const Text('Finalizar compra'), // nome do botão
                  ),
                ),

                const SizedBox(height: 8),

                // botão que esvazia o carrinho imediatamente
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        widget.appState.esvaziarCarrinho(); // apaga todos os produtos
                      });
                    },
                    child: const Text('Esvaziar carrinho'), // nome do botão
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}