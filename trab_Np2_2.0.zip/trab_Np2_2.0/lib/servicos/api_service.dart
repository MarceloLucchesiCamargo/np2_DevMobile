import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../modelos/produto.dart';

// classe que cuida de pegar dados da api
// isso evita repetir codigo de internet em outras partes do app
class ApiService {
  // endereço principal da api onde os produtos são buscados
  static const String _baseUrl = 'https://fakestoreapi.com';

  // método que pega a lista de produtos da api
  // isso manda um pedido para a api e espera a resposta
  // depois transforma o texto recebido em objetos produto que o app entende
  Future<List<Produto>> buscarProdutos() async {
    // aqui juntamos o endereço principal com a parte "products"
    // isso cria o endereço completo que vamos acessar
    final uri = Uri.parse('$_baseUrl/products');

    // aqui realmente fazemos o pedido para a internet
    // isso aguarda a api responder
    final http.Response resposta = await http.get(uri);

    // se a api respondeu tudo certo
    if (resposta.statusCode == 200) {
      // isso guarda o texto enviado pela api
      final corpo = resposta.body;

      // isso transforma o texto em uma estrutura que o dart entende
      // geralmente vira lista ou mapa
      final dados = jsonDecode(corpo);

      // se a resposta for uma lista, quer dizer que tem vários produtos
      if (dados is List) {
        // criamos uma lista vazia para guardar os produtos já convertidos
        final List<Produto> produtos = [];

        // aqui passamos por cada item da lista
        for (final item in dados) {
          // se o item já for um mapa com chaves e valores de texto
          // transformamos ele em um objeto produto
          if (item is Map<String, dynamic>) {
            produtos.add(Produto.fromJson(item));

          // caso o mapa venha em outro formato, convertemos e depois criamos o produto
          } else if (item is Map) {
            produtos.add(Produto.fromJson(item.cast<String, dynamic>()));
          }
        }

        // no final, devolvemos a lista de produtos pronta
        return produtos;

      } else {
        // isso acontece quando a api não envia uma lista como esperado
        throw Exception('resposta inesperada da api');
      }

    } else {
      // isso só aparece no modo debug quando algo deu errado na api
      if (kDebugMode) {
        print('erro ao buscar produtos: statusCode=${resposta.statusCode}, body=${resposta.body}');
      }

      // isso avisa que o pedido deu errado
      throw Exception('erro ao buscar produtos (código ${resposta.statusCode})');
    }
  }
}
