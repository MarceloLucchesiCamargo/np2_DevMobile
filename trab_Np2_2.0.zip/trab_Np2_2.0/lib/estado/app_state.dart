// classe que guarda todos os dados principais do app enquanto ele está aberto
import '../modelos/produto.dart';

// classe que centraliza informações do usuário, endereço e carrinho
class AppState {
  // nome da pessoa que está usando o app
  String? nomeUsuario;

  // e-mail da pessoa que está usando o app
  String? emailUsuario;

  // dados do endereço de entrega informados pelo usuário
  String? cidadeEntrega;
  String? estadoEntrega;
  String? cepEntrega;
  String? bairroEntrega;
  String? ruaEntrega;
  String? numeroEntrega;

  // lista interna que guarda todos os produtos adicionados ao carrinho
  // cada vez que um produto é adicionado ele entra na lista
  final List<Produto> _itensCarrinho = [];

  // permite ver a lista de itens sem permitir alterações diretas nela
  List<Produto> get itensCarrinho => List.unmodifiable(_itensCarrinho);

  // registra o e-mail da pessoa que acabou de fazer login
  void fazerLogin(String email) {
    emailUsuario = email;
  }

  // apaga todas as informações do usuário e limpa o carrinho
  // isso simula sair da conta
  void fazerLogout() {
    nomeUsuario = null;
    emailUsuario = null;
    cidadeEntrega = null;
    estadoEntrega = null;
    cepEntrega = null;
    bairroEntrega = null;
    ruaEntrega = null;
    numeroEntrega = null;
    _itensCarrinho.clear();
  }

  // atualiza todos os dados do usuário e do endereço de entrega
  // usado quando a pessoa salva alterações no perfil
  void atualizarPerfil({
    required String nome,
    required String email,
    required String cidade,
    required String estado,
    required String cep,
    required String bairro,
    required String rua,
    required String numero,
  }) {
    nomeUsuario = nome;
    emailUsuario = email;
    cidadeEntrega = cidade;
    estadoEntrega = estado;
    cepEntrega = cep;
    bairroEntrega = bairro;
    ruaEntrega = rua;
    numeroEntrega = numero;
  }

  // adiciona um produto ao carrinho colocando ele dentro da lista interna
  void adicionarAoCarrinho(Produto produto) {
    _itensCarrinho.add(produto);
  }

  // remove apenas uma unidade do produto passado como parâmetro
  // útil para diminuir a quantidade dele no carrinho
  void removerUmaUnidadeDoCarrinho(Produto produto) {
    final index = _itensCarrinho.indexWhere((p) => p.id == produto.id);
    if (index != -1) {
      _itensCarrinho.removeAt(index);
    }
  }

  // remove todas as unidades do mesmo produto da lista
  // limpa completamente aquele item do carrinho
  void removerTodasUnidadesDoProduto(Produto produto) {
    _itensCarrinho.removeWhere((p) => p.id == produto.id);
  }

  // limpa totalmente o carrinho removendo todos os produtos da lista
  void esvaziarCarrinho() {
    _itensCarrinho.clear();
  }

  // calcula o valor total do carrinho somando o preço de todos os itens
  double get totalCarrinho {
    return _itensCarrinho.fold(
      0.0,
      (total, produto) => total + produto.preco,
    );
  }

  // mostra quantos itens existem no carrinho no total
  int get quantidadeTotalCarrinho => _itensCarrinho.length;

  // método antigo que faz a mesma coisa que remover uma unidade
  void removerDoCarrinho(Produto produto) {
    removerUmaUnidadeDoCarrinho(produto);
  }
}
