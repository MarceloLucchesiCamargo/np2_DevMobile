class RotasApp {
  // esse nome representa a tela de login
  // serve para abrir a tela de login usando navegação por nome
  static const String loginPage = '/login-page';

  // esse nome representa a tela de criar conta
  // usado quando a pessoa ainda não tem cadastro
  static const String registroPage = '/registro-page';

  // esse nome representa a tela principal da loja
  // aqui aparece a lista de produtos
  static const String lojaPage = '/loja-page';

  // esse nome representa a tela que mostra os detalhes de um produto
  // ela recebe um produto quando é chamada
  static const String detalhesProdutoPage = '/detalhes-produto-page';

  // esse nome representa a tela do carrinho
  // onde aparecem todos os itens que a pessoa escolheu
  static const String carrinhoPage = '/carrinho-page';

  // esse nome representa a tela de perfil
  // onde a pessoa vê seus dados e pode sair da conta
  static const String perfilPage = '/perfil-page';
}
