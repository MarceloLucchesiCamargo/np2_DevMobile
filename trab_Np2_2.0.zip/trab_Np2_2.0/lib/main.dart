import 'package:flutter/material.dart';

import 'estado/app_state.dart';
import 'rotas.dart';
import 'pages/login_page.dart';
import 'pages/registro_page.dart';
import 'pages/loja_page.dart';
import 'pages/detalhes_produto_page.dart';
import 'pages/carrinho_page.dart';
import 'pages/perfil_page.dart';
import 'modelos/produto.dart';

void main() {
  // isso inicia o app e mostra na tela o widget principal
  runApp(const LojaFakeMegaStoreApp());
}

// essa classe é o coração do app
// ela é o primeiro widget que o flutter usa
// ela também cria o estado geral que será usado em todas as telas
class LojaFakeMegaStoreApp extends StatelessWidget {
  const LojaFakeMegaStoreApp({super.key});

  // aqui criamos uma única caixa de estado para guardar informações importantes
  // isso inclui: usuário logado, itens do carrinho e endereço
  // essa caixa é criada apenas uma vez e entregue para todas as telas
  static final AppState appState = AppState();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // nome que aparece em alguns lugares do app
      title: 'Loja Fake MegaStore',

      // isso tira a faixa de debug do canto da tela
      debugShowCheckedModeBanner: false,

      // aqui definimos as cores e aparência do app
      // o azul será usado como base para o tema
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),

      // essa é a primeira tela que aparece quando o app abre
      initialRoute: RotasApp.loginPage,

      // aqui registramos todas as telas do app usando nomes curtos
      // quando uma rota for chamada, a tela correspondente será aberta
      routes: {
        RotasApp.loginPage: (context) => LoginPage(appState: appState),
        RotasApp.registroPage: (context) => RegistroPage(appState: appState),
        RotasApp.lojaPage: (context) => LojaPage(appState: appState),
        RotasApp.carrinhoPage: (context) => CarrinhoPage(appState: appState),
        RotasApp.perfilPage: (context) => PerfilPage(appState: appState),
      },

      // isso é chamado quando precisamos abrir uma tela que recebe algo junto
      // aqui usamos isso para abrir os detalhes de um produto
      onGenerateRoute: (settings) {
        // se a rota pedida for detalhes do produto
        if (settings.name == RotasApp.detalhesProdutoPage) {
          // esperamos que foi enviado um produto junto com a rota
          final produto = settings.arguments as Produto;

          // aqui criamos a tela de detalhes passando o produto recebido
          return MaterialPageRoute(
            builder: (context) =>
                DetalhesProdutoPage(produto: produto, appState: appState),
          );
        }

        // se pedirem uma rota desconhecida, voltamos para o login
        return MaterialPageRoute(
          builder: (context) => LoginPage(appState: appState),
        );
      },
    );
  }
}
