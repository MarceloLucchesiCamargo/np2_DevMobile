// classe que guarda as informações de um produto
class Produto {
  // campos que guardam os dados principais do produto
  // id → identifica o produto
  // titulo → nome que aparece na tela
  // descricao → texto explicando o produto
  // preco → valor do produto
  // imagemurl → endereço da imagem na internet
  // categoria → tipo de produto
  final int id;
  final String titulo;
  final String descricao;
  final double preco;
  final String imagemUrl;
  final String categoria;

  // construtor que cria um produto com todos os dados obrigatórios
  // isso é usado sempre que queremos montar um produto manualmente ou pela fábrica
  Produto({
    required this.id,
    required this.titulo,
    required this.descricao,
    required this.preco,
    required this.imagemUrl,
    required this.categoria,
  });

  // fábrica que transforma um mapa (json) em um objeto produto
  // isso permite pegar o retorno da api e virar um produto pronto
  // também corrige o preço caso venha como número inteiro ou decimal
  factory Produto.fromJson(Map<String, dynamic> json) {
    final dynamic precoBruto = json['price'];

    double precoConvertido;
    if (precoBruto is int) {
      // transforma inteiro em decimal para evitar erro
      precoConvertido = precoBruto.toDouble();
    } else if (precoBruto is double) {
      // se já for decimal, apenas usa
      precoConvertido = precoBruto;
    } else {
      // se vier errado, deixa zero para não quebrar
      precoConvertido = 0.0;
    }

    // retorna um produto preenchido com os valores vindos do json
    return Produto(
      id: json['id'] ?? 0,
      titulo: json['title'] ?? '',
      descricao: json['description'] ?? '',
      preco: precoConvertido,
      imagemUrl: json['image'] ?? '',
      categoria: json['category'] ?? '',
    );
  }

  // transforma um produto em um mapa (json)
  // isso é usado quando queremos enviar ou salvar esses dados
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': titulo,
      'description': descricao,
      'price': preco,
      'image': imagemUrl,
      'category': categoria,
    };
  }

  // cria uma cópia do produto mudando só o que quisermos
  // isso é útil quando precisamos alterar um campo sem mexer nos outros
  Produto copyWith({
    int? id,
    String? titulo,
    String? descricao,
    double? preco,
    String? imagemUrl,
    String? categoria,
  }) {
    return Produto(
      id: id ?? this.id,
      titulo: titulo ?? this.titulo,
      descricao: descricao ?? this.descricao,
      preco: preco ?? this.preco,
      imagemUrl: imagemUrl ?? this.imagemUrl,
      categoria: categoria ?? this.categoria,
    );
  }
}
